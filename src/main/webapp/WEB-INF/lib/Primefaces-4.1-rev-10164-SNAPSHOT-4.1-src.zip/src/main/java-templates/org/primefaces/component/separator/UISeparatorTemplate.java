
    public final static String DEFAULT_STYLE_CLASS = "ui-separator ui-state-default ui-corner-all";