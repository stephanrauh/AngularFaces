
    public static final String STATIC_CONTAINER_CLASS = "ui-menu ui-slidemenu ui-widget ui-widget-content ui-corner-all ui-helper-clearfix";
    public static final String DYNAMIC_CONTAINER_CLASS = "ui-menu ui-slidemenu ui-menu-dynamic ui-widget ui-widget-content ui-corner-all ui-helper-clearfix ui-shadow";
    public static final String WRAPPER_CLASS = "ui-slidemenu-wrapper";
    public static final String CONTENT_CLASS = "ui-slidemenu-content";
    public static final String BACKWARD_CLASS = "ui-slidemenu-backward ui-widget-header ui-corner-all ui-helper-clearfix";
    public static final String BACKWARD_ICON_CLASS = "ui-icon ui-icon-triangle-1-w";