
    public final static String CONTAINER_CLASS = "ui-log ui-widget ui-widget-content ui-corner-all";
    public final static String HEADER_CLASS = "ui-log-header ui-widget-header ui-helper-clearfix";
    public final static String CONTENT_CLASS = "ui-log-content";
    public final static String ITEMS_CLASS = "ui-log-items";
    public final static String CLEAR_BUTTON_CLASS = "ui-log-button ui-log-clear ui-corner-all";
    public final static String ALL_BUTTON_CLASS = "ui-log-button ui-log-all ui-corner-all";
    public final static String INFO_BUTTON_CLASS = "ui-log-button ui-log-info ui-corner-all";
    public final static String DEBUG_BUTTON_CLASS = "ui-log-button ui-log-debug ui-corner-all";
    public final static String WARN_BUTTON_CLASS = "ui-log-button ui-log-warn ui-corner-all";
    public final static String ERROR_BUTTON_CLASS = "ui-log-button ui-log-error ui-corner-all";