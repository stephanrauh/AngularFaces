
    public final static String STYLE_CLASS = "ui-checkbox ui-widget";
    public final static String CHECKBOX_BOX_CLASS = "ui-checkbox-box ui-widget ui-corner-all ui-state-default";
    public final static String CHECKBOX_INPUT_WRAPPER_CLASS = "ui-helper-hidden";
    public final static String CHECKBOX_ICON_CLASS = "ui-checkbox-icon";
    public final static String CHECKBOX_CHECKED_ICON_CLASS = "ui-icon ui-icon-check";
    public final static String LABEL_CLASS = "ui-checkbox-label";

    public String getInputClientId() {
        return this.getClientId(getFacesContext()) + "_input";
    }