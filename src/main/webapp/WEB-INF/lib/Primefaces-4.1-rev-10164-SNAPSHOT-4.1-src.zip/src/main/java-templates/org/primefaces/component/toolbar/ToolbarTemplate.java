
    public static String CONTAINER_CLASS = "ui-toolbar ui-widget ui-widget-header ui-corner-all ui-helper-clearfix";
    public static String SEPARATOR_CLASS = "ui-separator";
    public static String SEPARATOR_ICON_CLASS = "ui-icon ui-icon-grip-dotted-vertical";