    
    public static final String CONTAINER_CLASS = "ui-confirm-dialog ui-dialog ui-widget ui-widget-content ui-overlay-hidden ui-corner-all ui-shadow";
    public static final String BUTTONPANE_CLASS = "ui-dialog-buttonpane ui-widget-content ui-helper-clearfix";
    public static final String SEVERITY_ICON_CLASS = "ui-confirm-dialog-severity";
    public static final String MESSAGE_CLASS = "ui-confirm-dialog-message";

    public boolean isRTL() {
        return this.getDir().equalsIgnoreCase("rtl");
    }
