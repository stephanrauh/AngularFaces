import javax.faces.component.UINamingContainer;

    public static final String CONTAINER_CLASS = "ui-selectmanymenu ui-inputfield ui-widget ui-widget-content ui-corner-all";
    public static final String ITEM_CLASS = "ui-selectlistbox-item ui-corner-all";